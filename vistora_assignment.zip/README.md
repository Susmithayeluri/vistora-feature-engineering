# Vistora Feature Engineering – Snowflake Assignment

### 👩‍💻 Author
**Susmitha Yeluri**

---

## 🧠 Project Overview
This project demonstrates how to build a **feature store** in **Snowflake** using SQL.  
The goal is to simulate customer data, transactions, and web events to generate useful customer-level features.

---

## ⚙️ Steps Performed

1. **Database Setup**
   - Created and used database: `VISTORA_DB`
   - Schema used: `PUBLIC`

2. **Data Generation**
   - Created synthetic datasets:
     - `CUSTOMERS` – 1,000 customers  
     - `TRANSACTIONS` – 10,000 records  
     - `WEB_EVENTS` – 30,000 events

3. **Feature Engineering**
   - Joined customer, transaction, and web event data.
   - Calculated features like:
     - `TOTAL_TRANSACTIONS`
     - `TOTAL_SPENT`
     - `TOTAL_WEB_EVENTS`
     - `ENGAGEMENT_SCORE`

4. **Visualization**
   - Plotted top-spending customers using Snowflake’s built-in chart tool.

---

## 📊 Outputs
- ✅ `CUSTOMERS` → 1,000 rows  
- ✅ `TRANSACTIONS` → 10,000 rows  
- ✅ `WEB_EVENTS` → 30,000 rows  
- ✅ `CUSTOMER_FEATURES` created with aggregated insights

---

## 📂 Files in This Repository
| File Name | Description |
|------------|-------------|
| `feature_engineering_snowflake.sql` | Main SQL script executed in Snowflake |
| `vistora_feature_engineering_presentation.pptx` | PowerPoint summary of project |
| `README.md` | Project documentation |
| `snowflake_output.png` | Screenshot of Snowflake chart (optional) |

---

## 🧾 Tools Used
- **Snowflake** – Data Warehouse
- **SQL** – Data generation and feature creation
- **GitHub** – Version control and submission
- **PowerPoint** – Presentation deliverable

---

## 📬 Contact
For any queries, contact:  
📧 `susmithayeluri8@gmail.com`
